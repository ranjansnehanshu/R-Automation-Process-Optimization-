library(readxl)
library(reshape2)
library(tidyr)

copyPaste <- function(df1,df2,map){
  for(i in 1:nrow(map)){df1[map[i,1]]<-df2[map[i,2]]}
  return(df1)}

raw <- read_excel(file.choose(),sheet = "SOV Template",skip = 3)
sov <- raw[1:64,]
sov <- sov[,sapply(sov,function(x)!all(is.na(x)))]
sov <- sov[,c(-(1:3),-5)]
sov <- sov[!duplicated(sov$`Location Number`),]
sov <- melt(sov,id="Location Number",variable.name = "LocNum")
sov <- spread(sov,`Location Number`,value=value)

mappedheaders <- read.csv("~/carmap.csv",stringsAsFactors = F)
output <- as.data.frame(matrix(ncol=28,nrow=nrow(sov)))
names(output) <- read.csv("~/carheaders.csv",header=F,stringsAsFactors=F)$V1
output <- copyPaste(output,sov,mappedheaders)
output$`Engineered Foundation` <- 1
output$`# of Risks/Buildings` <- 1
output$`Country Scheme` <- "ISO3A"
output$`Other - PML` <- output$`Total PML`
sov[c("Contract Works","Existing Property","Advance Loss Of Profits (ALOP)")][is.na(sov[c("Contract Works","Existing Property","Advance Loss Of Profits (ALOP)")])] <- 0
output$`Building (Other)` <- as.numeric(sov$`Contract Works`) + as.numeric(sov$`Existing Property`)
output$`Time Element (Other)` <- as.numeric(sov$`Advance Loss Of Profits (ALOP)`)

# Codes in RMS scheme based on description
descMapping <- read.csv("~/constDescp.csv")
output$`Construction Scheme` <- "RMS"
output$`Construction Class` <- as.character(descMapping$RMS.Code[match(sov$`Construction Description`,descMapping$Description)])
output$`Occupancy Scheme` <- "SIC"
output$`Occupancy Type` <- sov$`3 Digit SIC Code or 4 Digit SIC Code`
output$`Year Built` <- format(Sys.Date(),"%Y")

output$`Contract Works Start Date` <- format(as.Date(as.integer(output$`Contract Works Start Date`),origin ="1899-12-30"),"%m/%d/%y")
output$`Contract Works End Date` <- format(as.Date(as.integer(output$`Contract Works End Date`),origin ="1899-12-30"),"%m/%d/%y")
output$Currency <- substr(output$Currency,1,3)
write.csv(output,"Working.csv",row.names = F,na="")