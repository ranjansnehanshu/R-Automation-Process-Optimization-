dataFile <-file.choose()
path <- sub("\\\\[^\\\\]*$","", dataFile)

options( java.parameters = "-Xmx2500m")
library(xlsx)
#Assuming that location name is always correctly filled
dat <- read.xlsx2(dataFile, startRow = 24,colIndex = 2,sheetName = "Loc Info",colClasses = "character")
dat<-dat[!(dat=="")]
dat <- read.xlsx2(dataFile, startRow = 24,endRow=length(dat)+24,sheetName = "Loc Info",colClasses = c("integer","character","character","character","character","character","integer","integer","integer","character","integer","character","character","character","character","character","character","character","integer","integer","integer","integer","integer","integer","integer","integer","integer","integer","character","character","character","character"))

# RMS Construction dictionary
const <- list("A"=3,"B"=4,"C"=2,"D"=1)
#RMScodes<-const[substr(levels(droplevels(dat$Construction.Class)),start=1,stop=1)]
RMSCodes <- const[substr(as.character(dat$Construction.Class),1,1)]

scrubbingTemplate <- as.data.frame(matrix(nrow=nrow(dat),ncol = 23))
names(scrubbingTemplate) <- c("Location Number","Location Name","Address","City/Town","Zip/Postal Code","State/Province","Country Scheme","Country Code","Latitude","Longitude","# of Risks/Buildings","Construction Scheme","Construction Class","Occupancy Scheme","Occupancy Type","Number of Stories","Year Built","Floor Area","Floor Area Unit","Currency","Building (Other)","Content (Other)","Time Element (Other)")

scrubbingTemplate$`Location Number` <- 1:nrow(dat)
scrubbingTemplate$`Location Name` <- dat$Location.Name
scrubbingTemplate$Address <- dat$Street.Address
scrubbingTemplate$`City/Town` <- dat$City
scrubbingTemplate$`Zip/Postal Code` <- dat$Postal.Code
scrubbingTemplate$`State/Province` <- dat$State
scrubbingTemplate$`Country Scheme` <- "ISO3A"
scrubbingTemplate$`Country Code` <- dat$Country.Code
scrubbingTemplate$Latitude <- dat$Latitude
scrubbingTemplate$Longitude <- dat$Longitude
scrubbingTemplate$`# of Risks/Buildings` <- 1
scrubbingTemplate$`Construction Scheme` <- "RMS"
scrubbingTemplate$`Construction Class` <- RMSCodes
scrubbingTemplate$`Occupancy Scheme` <- "SIC"
scrubbingTemplate$`Occupancy Type` <- dat$SIC.CODE
scrubbingTemplate$`Number of Stories` <- dat$X..of.stories
scrubbingTemplate$`Year Built` <- dat$Year.Built
scrubbingTemplate$Currency <- dat$Currency
scrubbingTemplate$`Building (Other)` <- dat$Building.Sum.Insured
scrubbingTemplate$`Content (Other)` <- dat$Contents.incl.Plant...Machinery.Sum.Insured
scrubbingTemplate$`Time Element (Other)` <- dat$BI..Annual..Sum.Insured

write.xlsx(scrubbingTemplate,paste0(path,"\\Scrubbed.xlsx"),sheetName = "Working",showNA = F,row.names = F)
