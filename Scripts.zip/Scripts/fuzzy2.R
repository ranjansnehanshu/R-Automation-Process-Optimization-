library(readxl)
library(stringdist)
library(data.table)

# Clear memory: rm(list=setdiff(ls(),c("a","b","d","path","res","specialChars","special","equivalent")))

specialChars <- read.csv("~/specialChars.csv")
special <- paste0(specialChars$SpecialChar,collapse = "")
equivalent <- paste0(specialChars$Equivalent,collapse = "")

path <- "//ftwp8catfs1/core-property/EUROPE/Europe_Pre_Quote_2016/CP/United Kingdom/WALMART/2016/Aditya/"
filename <- "Abhishek.xlsx"
a <- read_excel(paste0(path,filename),sheet = "new")
b <- read_excel(paste0(path,filename),sheet = "old")

d <- data.table(expand.grid(a$Address,b$Address))
#j <- stringdist(tolower(d$Var1),tolower(d$Var2),method= "qgram")
#x <- data.table(cbind(d,j))
d[,Var1:=chartr(special,equivalent,Var1)]
d[,Var2:=chartr(special,equivalent,Var2)]
d[,j:=stringdist(tolower(d$Var1),tolower(d$Var2),method = "qgram")]
d[,len:=nchar(as.character(Var2))]
d[,nj:=j/(max(j,na.rm = T)-min(j,na.rm = T))]
d[,nlen:=len/(max(len,na.rm = T)-min(len,na.rm = T))]
d[,e:=nj/nlen]
res <- d[, .SD[which.min(e)], by = Var2]

fwrite(res[order(e)],"~/Output_fuzzy2.csv")