library(xlsx) # to handle excel files
library(stringr) # to handle strings
library(lubridate) # to handle dates 
library(XML) # handling HTML

# Helper functions
removeNA <- function(x){sub("NA, |, NA","",x)}
splitAndExtract <- function(input,delimiter,n){rapply(strsplit(input,split=delimiter),function(x)x[n])}

## Extracting data from PC report.

print("Please select the Property Central Report.")
pcData <- read.xlsx2(file.choose(),sheetIndex=1,stringsAsFactors=FALSE,colClasses = c("character","character","character","character","character","character","character","character","character","POSIXct","character","character","character","character","character","character","character","character","character","character","POSIXct","character","character","character","character","character","character","character","character"
))
print("Processing PC report...")
pcData<-as.data.frame(apply(pcData,2,str_trim))
pcData[pcData==""]<-NA
pcData$Create.Date.Time <- date(pcData$Create.Date.Time) # Slicing away time.

# Extracting APAC accounts
apac <- subset(pcData,Region=="APAC")
dump<-aggregate(apac,by=list(apac$PC.Request..),function(x){toString(unique(x))})

# Cleaning UW name, Complexity, branch and product segment
#dump$UW.Owner <- unlist(str_split(dump$UW.Owner,"-"))[seq(from=1,to=length(dump$UW.Owner)*2,by=2)]
dump$UW.Owner <- rapply(strsplit(dump$UW.Owner,"-"),function(x)x[[1]])
dump$Complexity.Type[dump$Complexity.Type == "Simple"] <- "Low"
dump$Complexity.Type[dump$Complexity.Type == "Complex"] <- "High"
dump$Product.Segment[grep("Commercial+",dump$Product.Segment)] <- "CP"
dump$Product.Segment[grep("Energy+",dump$Product.Segment)] <- "EER"

dump <- apply(dump,2,removeNA) # Possible bug: removeNA converts all elements to type 'char' & DF to matrix
dump[dump=="NA"] <- dump[dump=="(null)"] <-NA
dump <- as.data.frame(dump)
pcPre <- dump[dump$Request.Type=="Pre", ]
pcPost <- dump[dump$Request.Type=="Post", ]


#pcFormatted <- as.data.frame(matrix(ncol=56,nrow=nrow(pcPre)))
#names(pcFormatted) <- c("ID","E-Task","Entry type","Re_Run/Fresh","Account Name","Underwriter","Policy number","Region","Working Branch","Product Segment","TR Type","Task type","No of Location","CoE User Name","COE Reviewer","Sample_QA","TR Accumulation User","AIG Share (%)","Accounts Received Date","Inception Date","Expiry Date","Underwrite Requested Date","Revised UW Requested Date","Sent_for_Triage","Triage_Sent_Date","Triage_Received_Date","Triage Comment","Data Complexity","Data Priority","Data Quality","Tool used","Query_Reason","1st Query Send Date","Latest Query send Date","Latest Query Received Date","TIV Currency","Original TIV","Cleaned TIV","Status","Shipped Date","QA Comments","Comment1","Any Rerun","No of Runs","Reason for Rerun","Target Date SLA","Valid Submission number","Submission Number","s-Task ID","File Path","GES PP ID_PO No","Result Analysis Done","DataVera Used or not","DataVera Comment","AAL Currency","AAL")

pcFormatted <- as.data.frame(matrix(ncol=54,nrow=nrow(pcPre)))
names(pcFormatted) <- c("ID","E-Task","Entry type","Re_Run/Fresh","No of Runs","Reason for Re-Run","Account Name","Product Segment","Working Branch","GES PP ID_PO No","Status","CoE User Name","Accounts Received Date","Target Date SLA","Shipped Date","COE Reviewer","Underwriter","Tool used","No of Location","Underwriter Requested Date","Triage_Sent","Sent_for_Triage","Received_from_Triage","CoE Comments","AIG Share (%)","Inception Date","Expiry Date","Traige-Modelled_Twice","TIV Currency","Original TIV","Cleaned TIV","QA Comments","QA Status","Limit Type","Currency","Original Query Sent Date & Time (mm/dd/yyyy)","Latest Query Sent Date","Latest Query REceived Date & Time (mm/dd/yyyy)","Query Reason","Total Query Respond","TAT MET","Total TAT","Reasons for TAT miss","Policy number","Data Quality","Data Complexity","Data Priority","Region","Task type","Result Analysys Done","DataVera Used or not","DataVera Comment","AAL Currency","AAL")

#postFormatted <- as.data.frame(matrix(ncol=56,nrow=nrow(pcPost)))
#names(postFormatted) <- c("ID","E-Task","Entry type","Re_Run/Fresh","Account Name","Underwriter","Policy number","Region","Working Branch","Product Segment","TR Type","Task type","No of Location","CoE User Name","COE Reviewer","Sample_QA","TR Accumulation User","AIG Share (%)","Accounts Received Date","Inception Date","Expiry Date","Underwrite Requested Date","Revised UW Requested Date","Sent_for_Triage","Triage_Sent_Date","Triage_Received_Date","Triage Comment","Data Complexity","Data Priority","Data Quality","Tool used","Query_Reason","1st Query Send Date","Latest Query send Date","Latest Query Received Date","TIV Currency","Original TIV","Cleaned TIV","Status","Shipped Date","QA Comments","Comment1","Any Rerun","No of Runs","Reason for Rerun","Target Date SLA","Valid Submission number","Submission Number","s-Task ID","File Path","GES PP ID_PO No","Result Analysis Done","DataVera Used or not","DataVera Comment","AAL Currency","AAL")

postFormatted <- as.data.frame(matrix(ncol=54,nrow=nrow(pcPost)))
names(postFormatted) <- c("ID","E-Task","Entry type","Re_Run/Fresh","No of Runs","Reason for Re-Run","Account Name","Product Segment","Working Branch","GES PP ID_PO No","Status","CoE User Name","Accounts Received Date","Target Date SLA","Shipped Date","COE Reviewer","Underwriter","Tool used","No of Location","Underwriter Requested Date","Triage_Sent","Sent_for_Triage","Received_from_Triage","CoE Comments","AIG Share (%)","Inception Date","Expiry Date","Traige-Modelled_Twice","TIV Currency","Original TIV","Cleaned TIV","QA Comments","QA Status","Limit Type","Currency","Original Query Sent Date & Time (mm/dd/yyyy)","Latest Query Sent Date","Latest Query REceived Date & Time (mm/dd/yyyy)","Query Reason","Total Query Respond","TAT MET","Total TAT","Reasons for TAT miss","Policy number","Data Quality","Data Complexity","Data Priority","Region","Task type","Result Analysys Done","DataVera Used or not","DataVera Comment","AAL Currency","AAL")

# Removing blank rows
#pcPre <- pcPre[-grep("NA",rownames(pcPre)),]
#pcPost <- pcPost[-grep("NA",rownames(pcPost)),]

# Formatting PC requests for PreQuote
pcFormatted$`E-Task` <- pcPre$PC.Request..
pcFormatted$`Account Name` <- pcPre$Account.Name
pcFormatted$`Underwriter` <- pcPre$UW.Owner
pcFormatted$`Policy number` <- pcPre$Policy.Number
pcFormatted$Region <- pcPre$Region
pcFormatted$`Working Branch` <- pcPre$Working.Branch
pcFormatted$`Product Segment` <- pcPre$Product.Segment
pcFormatted$`Task type` <- pcPre$Transaction.Type
pcFormatted$`Inception Date` <- pcPre$Effective.Date
pcFormatted$`Expiry Date` <- pcPre$Expiration.Date
pcFormatted$`Submission Number` <- pcPre$e.Start.Subm..
pcFormatted$`GES PP ID_PO No` <- pcPre$Task.ID
pcFormatted$`Accounts Received Date` <- pcPre$Create.Date.Time # ????
pcFormatted$Triage_Sent <- "NA"

# Mandatory fields
pcFormatted$`Accounts Received Date` <- rapply(strsplit(as.character(pcFormatted$`Accounts Received Date`),","),function(x)x[[1]])
pcFormatted$`GES PP ID_PO No` <- stringr::str_replace_all(pcFormatted$`GES PP ID_PO No`,",","/")
pcFormatted$`Data Complexity` <- pcPre$Complexity.Type
pcFormatted$`Data Quality` <- "Standard"
pcFormatted$`Data Priority` <- "Normal"
pcFormatted$`QA Status` <- "QA not started"
pcFormatted$`Task type` <- "Pre bind"
pcFormatted$`Tool used` <- "GES"
pcFormatted$`No of Location` <- 0
pcFormatted$Status <- "Not Started"
pcFormatted$`Entry type` <- "Not Given"

# Formatting PC requests for Postbind
postFormatted$`E-Task` <- pcPost$PC.Request..
postFormatted$`Account Name` <- pcPost$Account.Name
postFormatted$`Underwriter` <- pcPost$UW.Owner
postFormatted$`Policy number` <- pcPost$POL_NO
postFormatted$`Region` <- pcPost$Region
postFormatted$`Working Branch` <- pcPost$WORKING_BRANCH
postFormatted$`Product Segment` <- pcPost$PRODUCT_SEGMENT
postFormatted$`Task type` <- pcPost$Transaction.Type
postFormatted$`Inception Date` <- pcPost$EFCTV_DT
postFormatted$`Expiry Date` <- pcPost$XPIRTN_DT
postFormatted$`Submission Number` <- pcPost$e.Start.Subm..
postFormatted$`GES PP ID_PO No` <- pcPost$Task.ID
postFormatted$`Accounts Received Date` <- pcPost$Create.Date.Time # ???
postFormatted$Triage_Sent <- "NA"

postFormatted$`Accounts Received Date` <- rapply(strsplit(as.character(postFormatted$`Accounts Received Date`),","),function(x)x[[1]])

write.csv(pcFormatted,"apacPrequote.csv",na="",row.names = F)
write.csv(postFormatted,"apacPostbind.csv",na="",row.names = F)
