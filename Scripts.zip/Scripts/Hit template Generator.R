library(XLConnect) # advanced Excel functions

rates <- read.csv("H:/Test/currencyRates.csv",stringsAsFactors = F)

print("Please choose Export SOV (CSV format).")
dataFile <-file.choose()
path <- sub("\\\\[^\\\\]*$","", dataFile)
exported <- read.csv(dataFile)

hitTemplate <- as.data.frame(matrix(nrow=nrow(exported),ncol = 25))
names(hitTemplate) <- c("Loc Num","Loc Name","Address Num","Street Name","County","City","Statecode","Postal Code","Country","Latitude","Longitude","Geocoding Resolution","Construction","Construction Description","Occupancy","Occupancy Description","Year Built","Num of Stories","Floor Area (sq. ft)","FL Zone","Distance to Coast","Bldg Value","Content Value","BI Value","TIV")

# Copy paste
hitTemplate$`Loc Num` <- exported$Location.Number
hitTemplate$`Loc Name` <- exported$Location.Name
hitTemplate$`Street Name` <- exported$Address
hitTemplate$County <- exported$County
hitTemplate$City <- exported$City.Town
hitTemplate$`Postal Code` <- exported$Zip.Postal.Code
hitTemplate$Country <- exported$Country
hitTemplate$Latitude <- exported$Latitude
hitTemplate$Longitude <- exported$Longitude
hitTemplate$`Geocoding Resolution` <- exported$Location.Precision.Description
hitTemplate$Construction <- paste(exported$Construction.Scheme,exported$Construction.Class)
hitTemplate$`Construction Description` <- exported$Construction.Description
hitTemplate$Occupancy <- paste(exported$Occupancy.Scheme,exported$Occupancy.Type)
hitTemplate$`Occupancy Description` <- exported$Occupancy.Description
hitTemplate$`Year Built` <- exported$Year.Built

accName <- exported$Data.Source.file.name[1]
region <- "APAC"

mulFactor <- (1/rates$Conversion.Rate)[match(exported$Currency,rates$Currency)]
building <- mulFactor*exported$Building..Other.
content <- mulFactor*exported$Content..Other.
bi <- mulFactor*exported$Time.Element..Other.

hitTemplate$Building <- building
hitTemplate$Content <- content
hitTemplate$BI <- bi
hitTemplate$TIV <- building + content + bi

wb <- loadWorkbook(paste(path,"HIT Template.xlsx",sep="\\"),create=TRUE)
createSheet(wb,name="Location Summary")

## Writing data
writeWorksheet(wb,region,"Location Summary",startRow = 2, startCol = 2, header = F)
writeWorksheet(wb,accName,"Location Summary",startRow = 5, startCol = 2, header = F)
writeWorksheet(wb,hitTemplate,"Location Summary",startRow = 6, startCol = 2, header = T)
saveWorkbook(wb)