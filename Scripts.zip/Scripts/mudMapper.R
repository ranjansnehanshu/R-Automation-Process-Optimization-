setClass ("layer",
          representation ( amount ="numeric" ,
                           excess ="numeric" ,
                           participation ="numeric") ,
          prototype ( amount = 0 ,
                      excess = 0 ,
                      participation = 100))
setMethod ("show" , "layer" ,
           function ( object ){
             cat ("User defined layer.\n")
             cat (paste ( object@amount ,
                                      collapse ="x"))
             cat (" excess of" , paste ( object@excess ,
                                            collapse ="x"))
             cat (". Participation:" , object@participation , "%")
             cat ("\n")
           })
layer <- function(amount=0,excess=0,participation=0) # Wrapper function for creating layer objects
{
  return(new("layer",amount=amount,excess=excess,participation=participation))
}

mudmap <- function(h,r,colour="blue", rColour="orange"){
  
  # Create a new plot
  dev.cur()
  
  # "h" is the list of layers, r is list of reinsurance layers
  yvector <- numeric(0) # Vector to store all plotted y values
  
  for (i in 1:length(h)) 
  {yvector <- c(yvector,h[[i]]@amount+h[[i]]@excess,h[[i]]@excess)}
  
  yvector <- unique(sort(yvector))
  
  # Plotting limits of mudmap
  plot(c(0,100),c(0,max(yvector)),type = "n", xlab = "Participation (%)", ylab = "Values")
  title(main="Mudmap")
  
  #Plot the layers we play in 
  for (val in yvector){rect(0,0,100,val)}
  
  cat("Reinsurance summary:")
  if(missing(r)){cat(" No reinsurance.")}
  
  for(i in (1:length(h)))
  {
    rect(0,h[[i]]@excess,h[[i]]@participation,h[[i]]@amount+h[[i]]@excess,col = colour)
    if(!missing(r))
    {
      for (reinsurance in r)
      {
        if ((reinsurance@excess>=h[[i]]@excess)&&(reinsurance@excess<(h[[i]]@excess+h[[i]]@amount)))        
        {
          cat("\n[",paste(h[[i]]@amount),"XS",paste(h[[i]]@excess),"]",paste((min(h[[i]]@excess+h[[i]]@amount,reinsurance@excess+reinsurance@amount)-reinsurance@excess)*h[[i]]@participation/100))
          cat(" excess of",paste((reinsurance@excess-h[[i]]@excess)*h[[i]]@participation/100))
          cat(". Cession:",paste(reinsurance@participation/h[[i]]@participation*100),"%")
        }
        if(((reinsurance@excess+reinsurance@amount)>h[[i]]@excess)&&((reinsurance@excess<h[[i]]@excess)))
        {
          #cat("\n",paste((min(h[[i]]@excess+h[[i]]@amount,reinsurance@excess+reinsurance@amount)-reinsurance@excess)*h[[i]]@participation/100))
          cat("\n[",paste(h[[i]]@amount),"XS",paste(h[[i]]@excess),"]",paste((reinsurance@excess+reinsurance@amount-h[[i]]@excess)*h[[i]]@participation/100))
          cat(" excess of 0")
          cat(". Cession:",paste(reinsurance@participation/h[[i]]@participation*100),"%")
        }
      }
    }
    }
  
  
  # Section that is run if reinsurance list is passed
  if(!missing(r))
  {
    for (i in 1:length(r))
    {
      o <- sort(c(yvector,r[[i]]@amount+r[[i]]@excess,r[[i]]@excess))
      start <- match(r[[i]]@excess,o)
      end <- match(r[[i]]@amount+r[[i]]@excess,o)
      if (identical(o[start],o[start+1])){start = start+1}
      o <- o[start:end]
      
     for (k in 1:(length(o)-1)){rect(0,o[k],r[[i]]@participation,o[k+1],col=rColour)}
      
    }

  }
}


