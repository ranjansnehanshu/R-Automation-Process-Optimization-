#crh <- crhRaw

setwd("//ftwp8catfs1/core-property/EUROPE/Europe_Pre_Quote_2016/CP/Ireland/Crh Public Limited Company/Cleansed")

crh$BU.Country <- NULL
write.csv(sort(table(crh$Primary.Use.of.Premises),decreasing = T),"Occmap.csv")

maps <- read.csv("mapped.csv")
crh$occScheme <- maps$Scheme[match(crh$Primary.Use.of.Premises,maps$Description)]
crh$occCode <- maps$Code[match(crh$Primary.Use.of.Premises,maps$Description)]

# Default codes for NA's
crh[is.na(crh$occCode),]$occScheme <- "SIC"
crh[is.na(crh$occCode),]$occCode <- "3271"

crh$Buildings..EUR..2017.Gross[is.na(crh$Buildings..EUR..2017.Gross)] <- 0
crh$Cost.of.Debris.Removal..EUR..2017.Gross[is.na(crh$Cost.of.Debris.Removal..EUR..2017.Gross)] <- 0
crh$Total.Property.Value..EUR..2017.Gross[is.na(crh$Total.Property.Value..EUR..2017.Gross)] <- 0
crh$Total.BI.Value..EUR..2017.Gross[is.na(crh$Total.BI.Value..EUR..2017.Gross)] <- 0
crh$Total.ME.Value..EUR..2017.Gross[is.na(crh$Total.ME.Value..EUR..2017.Gross)] <- 0

crh$BuildingVal <- crh$Buildings..EUR..2017.Gross + crh$Cost.of.Debris.Removal..EUR..2017.Gross
crh$ContentVal <- crh$Total.Property.Value..EUR..2017.Gross - crh$BuildingVal + crh$Total.ME.Value..EUR..2017.Gross
crh$BIVal <- crh$Total.BI.Value..EUR..2017.Gross

table(crh$Construction.Type)
library(stringr)
frames <- str_extract_all(crh$Construction.Type,"(\\S+)\\s*[Ff]rame")
frames1 <- lapply(frames,function(x)trimws(gsub("frame","",x,ignore.case = T)))

weakestConst <- function(vec)
{
  set <- list("wood" = 1, "masonry" = 2, "concrete" = 3, "steel" = 4)
  coded <- lapply(vec,function(x)set[tolower(x)])
  return(sapply(coded,function(x)min(unlist(x))))
}

construction <- weakestConst(frames1) # RMS construction codes
construction[construction==Inf] <- 0
crh$ConstCodes <- construction
uncoded <- crh[construction==0,]
unique(uncoded$Construction.Type)
crh$ConstCodes[grepl("combustible|resistive",crh$Construction.Type)&crh$ConstCodes==0] <- 3 # RMS 3

#Zip codes
any(is.na(crh$Post.Zip.Code)) # No blanks
crh$Post.Zip.Code[grep("xxx|\\*|n/a|Kildare|Dub",crh$Post.Zip.Code,ignore.case = T)] <- NA
crh <- crh[crh$Country.code!="invalid input",] # remove loc # 5023 Dist North

names(crh)[4:13] #Fields with location info

crh$TIV <- crh$BuildingVal + crh$ContentVal + crh$BIVal
crh1<-apply(crh,2,trimws) # apply changes datatype to char # breaks 'sum'
crh1[crh1==""] <- NA
crh1[rowSums(apply(as.data.frame(crh1)[4:13],2,is.na))!=0,]
crh1 <- as.data.frame(crh1)
crh1$ContentVal <- as.numeric(crh1$ContentVal)
crh2 <- crh[rowSums(apply(crh1[4:13],2,is.na))==10,] # 10 = no of fields
unkVal <- sum(crh2$ContentVal) # UNK value
crh3 <- crh[rowSums(apply(crh1[4:13],2,is.na))!=10,]

