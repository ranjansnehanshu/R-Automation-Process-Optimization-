hu <- read.csv(file.choose(),sep="|")
View(hu[,sapply(hu,function(x)all(!is.na(x)))])
DT::datatable(hu[,sapply(hu,function(x)all(!is.na(x)))])