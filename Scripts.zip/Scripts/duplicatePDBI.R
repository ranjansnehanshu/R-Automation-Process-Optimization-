#library(xlsx)

# filePath = "C:/Documents and Settings/Administrator/My Documents/"
# fileName = "sampleSOV.xlsx"

# filePath <- readline("Please enter the file path: ")
# filePath <- gsub("\\\\", "/", filePath)
# fileName <- paste("/",readline("Please enter filename with extension: "),sep="")


dat <- read.csv(file.choose(),stringsAsFactors = F)
duplicates <- subset(dat,(((Building..Other. + Content..Other.)>0)&(Time.Element..Other. > 0)))
notDuplicates <- subset(dat,!(((Building..Other. + Content..Other.)>0)&(Time.Element..Other. > 0)))

pd <- duplicates
pd["Location.Name"] <- lapply(pd["Location.Name"],function (x) paste(x,"_PD",sep=""))
pd["Time.Element..Other."]=0

bi <- duplicates
bi["Location.Name"] <- lapply(bi["Location.Name"],function (x) paste(x,"_BI",sep=""))
bi["Content..Other."]=0 
bi["Building..Other."]=0

dat <- rbind(notDuplicates,pd,bi)
dat <- dat[with(dat,order(dat["Location.Number"])),]
dat["Location.Number"] <- 1:nrow(dat)
write.csv(dat,"out3.csv",na="")

