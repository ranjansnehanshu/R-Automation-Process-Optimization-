mapping <- read.csv("H:/Test/airmap.csv",stringsAsFactors = F)
mapping$FullCode <- paste(mapping$Scheme,mapping$Code)

dataFile <- file.choose()
path <- sub("\\\\[^\\\\]*$","", dataFile)
sov <- read.csv(dataFile,stringsAsFactors = F)

locTemplate <- as.data.frame(matrix(nrow=nrow(sov),ncol=31))
names(locTemplate) <- c("Contract ID","Location ID","Inception Date","Expiration Date","City","Area (State)","Country (CLASIC/2 Code)","Latitude","Longitude","Replacement Value Building","Replacement Value Contents","Replacement Value Time","Currency","Number of Risk","Construction Code Type","Construction Building","Occupancy Code Type","Occupancy Code","Year Built","Stories","Limit Type","Limit A","Limit C","Limit D","Deductible Type","Deductible Building","Deductible Contents","Deductible Time","Location Perils","Location Name","Sublimit Area")
accTemplate <- as.data.frame(matrix(ncol=21))
names(accTemplate) <- c("Contract ID","Inception Date","Expiration Date","Currency","Layer ID","Layer Perils","Limit Type","Total Limit (Limit 1)","Participation Limit (Limit 2)","Assumed Amount","Participating Layer Amount","100% Layer Amount *","Attachment Amount","Deductible Type","Deductible Amount 1","Deductible Amount 2","Insured Name","Sublimit Area","Deductible type","Ded amt 1","Ded amt 2")

# Copy-paste
locTemplate$`Contract ID` <- 1 # 1 by default
locTemplate$`Location ID` <- 1:nrow(sov)
locTemplate$City <- sov$City.Town
locTemplate$`Country (CLASIC/2 Code)` <- sov$Country
locTemplate$Latitude <- sov$Latitude
locTemplate$Longitude <- sov$Longitude
locTemplate$`Number of Risk` <- 1 # 1 by default
locTemplate$`Replacement Value Building` <- sov$Building..Other.
locTemplate$`Replacement Value Contents` <- sov$Content..Other.
locTemplate$`Replacement Value Time` <- sov$Time.Element..Other.
locTemplate$Currency <- sov$Currency
locTemplate$`Construction Code Type` <- locTemplate$`Occupancy Code Type` <- "AIR"
locTemplate$`Year Built` <- sov$Year.Built
locTemplate$Stories <- sov$Number.of.Stories
locTemplate$`Location Perils` <- "PWH"


# Automapping constructions and occupancies
locTemplate$FullCode <- paste(sov$Construction.Scheme,sov$Construction.Class)
temp <- merge(mapping,locTemplate,by="FullCode",all.y = T) # Right outer join
temp <- temp[with(temp, order(`Location ID`)), ] # Ordering by location ID
locTemplate$`Construction Building` <- temp$AIR.code

locTemplate$FullCode <- paste(sov$Occupancy.Scheme,sov$Occupancy.Type)
temp <- merge(mapping,locTemplate,by="FullCode",all.y = T)
temp <- temp[with(temp, order(`Location ID`)), ]
locTemplate$`Occupancy Code` <- temp$AIR.code


# Writing Location file and account file
write.csv(locTemplate[,-which(names(locTemplate) == "FullCode")],paste0(path,"\\\\AIR_Locfile.csv"),na="",row.names = F)
write.csv(accTemplate,paste0(path,"\\\\AIR_Accountfile.csv"),na="",row.names = F)