library(xlsx) # to work with Excel workbooks
library(XLConnect) # advanced Excel functions
library(lubridate) # to handle dates without losing my sanity

# Preliminary housekeeping

folderPath <- "//Ftwp8catfs1.r1-core.r1.aig.net/CoE_India/APAC/Account_Modeling/Ad-hoc task/Monitoring of submissions-For Syd/2016/"
dataFile <- paste(folderPath,"data.xlsx",sep="/")
#trackerData <- read.xlsx2(dataFile,sheetIndex=1,colClasses = c("numeric","character","character","character","character","character","character","character","character","character","character","character","character","character","character","character","POSIXct","POSIXct","character","character","character","character","POSIXct","POSIXct","POSIXct","POSIXct","character","character","character","character","POSIXct","character","character","character","character","character","POSIXct","POSIXct","character","character","character","character","character","character","character","character","numeric","numeric","character","character","character","numeric"
#))  
trackerData <- read.xlsx2(dataFile,sheetIndex=1,stringsAsFactors=FALSE)
                                                               

subFolders <- paste(as.character(1:12),month.abb,sep=". ")
timeStamp <- as.character(Sys.Date())

dump <- trackerData[c("Policy.number","Account.Name","Inception.Date","Expiry.Date","Underwriter","Working.Branch","Accounts.Received.Date","Status","E.Task","Product.Segment"
)]

# Formats Excel dates to POSIX-ct
formatDate <- function (input){substr(as.POSIXct((as.numeric(input)-25569)*86400,origin = "1970-01-01"),1,10)}

# Set timezones to NULL
dump$Accounts.Received.Date <- formatDate(dump$Accounts.Received.Date)
dump$Inception.Date <- formatDate(dump$Inception.Date)
dump$Expiry.Date <- formatDate(dump$Expiry.Date)

#dump <- dump[dump$Accounts.Received.Date < ymd(20160715),] # Modify to compare with 15 of current month
dump <- dump[dump$Accounts.Received.Date < ymd(paste0("2016-",as.character(month(now())),"-15")),]
dump$Country <- NA # Initialising Country identifier
dump[grep("*AUS|Australia*",dump$Working.Branch),]$Country<-"Australia"
dump[grep("*CHINA|China",dump$Working.Branch),]$Country<-"China"
dump[grep("*New Zealand*",dump$Working.Branch),]$Country<-"New Zealand"
dump[is.na(dump$Country),]$Country<-as.vector(dump[is.na(dump$Country),]$Working.Branch) 
uniqueCountries <- sort(unique(dump$Country))

# Subsetting by Product segment
cp <- dump[dump$Product.Segment == "CP",]
eer <- subset(dump,Product.Segment == "EER"|Product.Segment == "CAR/EAR") # ?

for(i in 1:2)
{
  if(i == 1){
    dump <- cp
    segment = "CP"}
  else{
    dump <- eer
    segment = "EER"
  }
  
  for(mnth in 1:month(now()))
  {
    wbName <- paste0(segment,"_Post_Bind_Book_",month(mnth,label=TRUE)," ",year(now())%%1000,"_",timeStamp,".xlsx")
    setwd(paste(folderPath,subFolders[mnth],sep="/"))
    # detach("package:xlsx", unload=TRUE)  # Detach xlsx if function is masked 
    wb <- loadWorkbook(wbName,create=TRUE)
    createSheet(wb,name=uniqueCountries) # Create all sheets
    for(country in uniqueCountries)
    {
      filtered <- dump[dump$Country==country,] # Filter by country
      filtered <- filtered[month(filtered$Inception.Date)==mnth,] # Filter by Inception month
      filtered <- filtered[year(filtered$Inception.Date)==year(now()),] # Filter by year
      
      previousYear <- dump[year(dump$Inception.Date)!=year(now()),] # Filter by Inception year
      previousYear <- previousYear[previousYear$Country==country,] # filter by country
      previousYear <- previousYear[month(previousYear$Accounts.Received.Date)==month(mnth),] # filter by Acc. Recevied date
      
      output <- rbind(filtered,previousYear)
      output <- output[with(output, order(Accounts.Received.Date)), ] # Ordering by Acc.Received date
      output <- output[ , !(names(output) %in% c("Country","Product.Segment"))] # Drop Country column
      names(output) <- c("Policy number","Account Name","Inception Date","Expiry Date","Underwriter","Working Branch","Accounts Received Date","Status","E-Task")
      
      # Changing all statuses other than Shipped & On Query to WIP
      # output[(output$Status!="Shipped")&(output$Status!="On Query")] <- "WIP"
      
      description <- data.frame(Month_Year=paste(as.character(month(mnth,label=TRUE)),as.character(year(now()))),Post_bind_accounts_received = dim(output)[1])
      
      writeWorksheet(wb,output,country,startRow = 7, startCol = 2, header = TRUE) # Writing data
      writeWorksheet(wb,description,country,startRow = 2, startCol = 2, header = TRUE) # Writing description
      setColumnWidth(wb, sheet = country, column = 3:4, width = -1) # adjust width
    }
    saveWorkbook(wb) # Writes file to disk
  }
}
