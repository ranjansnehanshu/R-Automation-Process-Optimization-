#devtools::install_github("ropensci/RSelenium")
#remDr$screenshot
appURL <- "https://hris.excelityglobal.com/embrace/jsp/login.jsp"
library(RSelenium)
pJS <- phantom("//PNGSCITRIX02/abs/My Documents/phantomjs/phantomjs-2.1.1-windows/bin/phantomjs.exe")
remDr <- remoteDriver(browserName = "phantomjs")
remDr$open()
remDr$navigate(appURL)
remDr$findElement("id", "p1")$sendKeysToElement(list("5250101"))
remDr$findElement("id", "p2")$sendKeysToElement(list("zenblade93"))
remDr$findElement("id", "p3")$sendKeysToElement(list("aig"))
remDr$findElement("id", "logOn")$clickElement()
markAttendance <- "https://hris.excelityglobal.com/embrace/servlet/controller?module=OnlineAttendance&screen=DailyAttendance&action=View&markAttendace=Y&submitFlag=Y"
logout <- "https://hris.excelityglobal.com/embrace/servlet/logout"
remDr$navigate(markAttendance)
remDr$navigate(logout)