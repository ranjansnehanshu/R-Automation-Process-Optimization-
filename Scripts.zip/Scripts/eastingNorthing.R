#install.packages(c("proj4","rgdal"))
wgs84 = "+init=epsg:4326"
bng = '+proj=tmerc +lat_0=49 +lon_0=-2 +k=0.9996012717 +x_0=400000 +y_0=-100000 
+ellps=airy +datum=OSGB36 +units=m +no_defs'

ConvertCoordinates <- function(easting,northing) {
  out = cbind(easting,northing)
  mask = !is.na(easting)
  sp <-  sp::spTransform(sp::SpatialPoints(list(easting[mask],northing[mask]),proj4string=sp::CRS(bng)),sp::CRS(wgs84))
  out[mask,]=sp@coords
  out
}

test <- read.csv(file.choose())
index <- test$Easting==0
result <- ConvertCoordinates(test$Easting,test$Northing)
result[index,] <- NA
write.csv(result,"latlong.csv",na="",row.names = F)
