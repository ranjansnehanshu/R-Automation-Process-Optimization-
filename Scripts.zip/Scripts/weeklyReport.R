copyPaste <- function(df1,df2,map){
  for(i in 1:nrow(map)){df1[map[i,1]]<-df2[map[i,2]]}
  return(df1)}

#library(xlsx)
#tracker <- read.xlsx(file.choose(),1)
tracker <- read.csv(file.choose(),stringsAsFactors = F)
headers <- read.csv("H:/Weekly Report/mapHeaders.csv",stringsAsFactors = F)

output <- as.data.frame(matrix(ncol=43,nrow=nrow(tracker)))
names(output) <- read.csv("H:/Weekly Report/headers.csv",header=F,stringsAsFactors=F)$V1
output <- copyPaste(output,tracker,headers)

#output$SLNo <- 1:nrow(output)

write.csv(output,"Report.csv",na="",row.names=F)
